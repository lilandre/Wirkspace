ALTER TABLE `#__phocamaps_map` ADD COLUMN `custom_options` varchar(255) NOT NULL default '';
ALTER TABLE `#__phocamaps_map` ADD COLUMN `map_styles` text NOT NULL;



