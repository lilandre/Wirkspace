<?php
	/*
	* GMapFP Component Google Map for Joomla! 3.x
	* Version J3.79pro
	* Creation date: Octobre 2015
	* Author: Fabrice4821 - www.gmapfp.org
	* Author email: webmaster@gmapfp.org
	* License GNU/GPL
	*/

defined('_JEXEC') or die();

require_once(JPATH_ROOT.'/components/com_gmapfp/controllers/dropfiles.php');
?>
