DROP TABLE [#__gmapfp];
DELETE FROM [#__categories] WHERE [extension]='com_GMapFP';
DELETE FROM [#__categories] WHERE [extension]='com_gmapfp_groupes';
DROP TABLE [#__gmapfp_marqueurs];
DROP TABLE [#__gmapfp_personnalisation];
