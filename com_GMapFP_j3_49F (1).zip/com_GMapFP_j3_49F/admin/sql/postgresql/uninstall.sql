DROP TABLE IF EXISTS "#__gmapfp";
DELETE FROM "#__categories" WHERE extension='com_GMapFP';
DELETE FROM "#__categories" WHERE extension='com_gmapfp_groupes';
DROP TABLE IF EXISTS "#__gmapfp_marqueurs";
DROP TABLE IF EXISTS "#__gmapfp_personnalisation";
