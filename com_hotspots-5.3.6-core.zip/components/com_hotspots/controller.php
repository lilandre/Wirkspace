<?php
/**
 * @package    Hotspots
 * @author     DanielDimitrov <daniel@compojoom.com>
 * @date       01.08.14
 *
 * @copyright  Copyright (C) 2008 - 2013 compojoom.com . All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE
 */

jimport('joomla.application.component.controller');

defined('_JEXEC') or die ('Restricted access');

/**
 * Class HotspotsController
 *
 * @since  3.0
 */
class HotspotsController extends JControllerLegacy
{

}